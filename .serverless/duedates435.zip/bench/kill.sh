killall -9 node
node reset.js
