let fun = require('./handler').hello;

fun();
